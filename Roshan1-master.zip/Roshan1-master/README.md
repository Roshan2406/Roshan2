# maven-spring-web-project
Maven + Spring MVC Web Project Example

Project created for Amdocs Pune CP-DOF Training - April 2018
