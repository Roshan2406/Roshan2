package com.qaagility.controller;

public class Calcmul {

  public int mul() {
    //Adding comments
    return 3 * 6;
  
  }
  
  }
